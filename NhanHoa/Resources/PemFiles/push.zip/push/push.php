<?php
    $passphrase = 'nhanhoa123456';

    $ctx = stream_context_create();
	stream_context_set_option($ctx, 'ssl', 'local_cert', 'ck.pem');
    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

    $errstr = '';
    // Open a connection to the APNS server
    $fp = stream_socket_client(
							   'ssl://gateway.sandbox.push.apple.com:2195', $err,
                               $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

    //  $tHost = 'gateway.sandbox.push.apple.com;
    //  $tHost = 'gateway.push.apple.com';
    
    
    if (!$fp)
        exit("Failed to connect amarnew: $err $errstr" . PHP_EOL);

        echo 'Connected to APNS' . PHP_EOL;
   $deviceToken = $_REQUEST["deviceToken"];
   $callid = $_REQUEST["callid"];

    $message = "Incoming call from $callid";
    // Create the payload body
//    $body['call-id'] = $callid,
    $body['aps'] = array(
                          'badge' => +1,
                          'alert' => 'Test notification',
                          'sound' => 'default'
                          );
    
    
    $payload = json_encode($body);
    $deviceToken = 'c6c83975ff653416c4e8fb8ac273525ad601b709cf280a79e55f6148b5d40f61';
    
    // Build the binary notification
    $msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

    // Send it to the server
    $result = fwrite($fp, $msg, strlen($msg));

    if (!$result)
    echo 'Message not delivered' . PHP_EOL;
    else
    echo 'Message successfully delivered amar' .$message. PHP_EOL;

    // Close the connection to the server
    fclose($fp);
?>
